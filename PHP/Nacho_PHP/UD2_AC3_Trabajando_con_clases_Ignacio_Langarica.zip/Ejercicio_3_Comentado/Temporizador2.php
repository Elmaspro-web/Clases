<?php
/* L) Resulta que tienes un segundo hobby. Crea su clase asociada, heredará de la clase
abstracta. Necesitas contabilizar el tiempo dedicado a cada uno de ellos con métodos
que te permitan establecer un tiempo máximo y mínimo. Emplea alguna estructura que
te permita modularizarlo e implementarlo.*/
interface Temporizador2
{

    public function tiempoMin();
    public function tiempoMax();

}