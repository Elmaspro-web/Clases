<?php

interface Temporizador
{

    public function tienpoMin();
    public function tienpoMax();

}