<?php

abstract class Hobby
{
        function setNombre(string $nombre){}
        function getNombre(){}
}